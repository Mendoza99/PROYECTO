#ifndef METODOS_H
#define METODOS_H
#include <string.h>
#include <iomanip>
#include <fstream>
#include <iostream>
#include "nodos.h"
#include <stdlib.h>

using namespace std;

class Arbol{
private:
    Nodo *Nodos;
    string Ruta;
    int CC;
    int valorN;
public:
    Arbol(string ruta){
       this->Ruta = ruta;
        Nodos = new Nodo[50];
        CC = 0;
        valorN = 0;
    }

    void setRuta(string R){
        this->Ruta = R;
    }

    string getRuta(){
        return this->Ruta;
    }

    void addNodo(Nodo N){
        if(CC<25){
        Nodos[CC]= N;
        AsignarHijos(0,CC);
        CC++;
        }
    }

    void setNodo(int pos, Nodo N){
        if(pos>=0 && pos<=CC){
            Nodos[pos]= N;
        }
    }

    void remNodo(int pos){
                       if(pos>=0 && pos<CC){
                            Nodo *t=new Nodo[100];
                            int p=0;
                            for(int i=0;i<CC;i++){
                               if(pos!=i){
                                    t[p]=Nodos[i];
                                    p++;
                               }
                            }
                            //delete(personas);
                            Nodos->~Nodo();
                            Nodos=t;
                            CC--;}
                    }

    Nodo* getNodo(){
        return Nodos;
    }

    int getCC(){
        return CC;
    }

    string token(string cadena, string divisor, int pos){
           if(cadena.size()>0){
             char oracion[cadena.size()];
             for (int i=0;i<=cadena.size();i++)
             {
                   oracion[i]=cadena[i];
             }
             char *ptrtoken;
             int num=1;
             const char* d=divisor.c_str();
             ptrtoken = strtok(oracion , d);
             while(ptrtoken){
                 if(num==pos){
                    return ptrtoken;
                 }
                 ptrtoken = strtok(NULL, d);
                 num++;
             }
             return "";
           }else{
                 return "";
           }
    }

                    void escribir(){
                         ofstream Escribir;
                         Escribir.open(Ruta.c_str());
                         for (int i=0;i<CC;i++){
                             //El guardado es el siguiente, #nodo, Hijo izquierdo, Hijo Derecho, Valor del nodo
                             Escribir<<i<<";"
                                        <<Nodos[i].getHijoI()<<";"
                                       <<Nodos[i].getHijoD()<<";"
                                       <<Nodos[i].getValor()<<";"<<endl;
                         }
                          Escribir.close();
                   }

                    void leer(){
                                     fstream Leer;
                                     string linea;
                                     Nodos =new Nodo[25];
                                     CC=0;
                                     Leer.open(Ruta.c_str());
                                     while(! Leer.eof()){
                                             getline(Leer,linea);
                                             if(linea.size()>0){
                                               addNodo(Nodo(atoi(token(linea,";",4).c_str())));
                                             }
                                      }
                                     Leer.close();
    }

    void AsignarHijos(int N, int CN){
        //N es la posicion nodo a Evaluar, CN es la posicion del nodo que esta entrando
        if(CN != 0){
            if((this->Nodos[CN].getValor() >= this->Nodos[N].getValor()) && (this->Nodos[N].getD() == false)){
            //Si el nodo siguiente es mayor al nodo en el que estoy y ademas el nodo en el que estoy no tiene hijo derecho, se asigna este como el hijo derecho
                this->Nodos[N].setHijosD(CN);
                this->Nodos[CN].setAltura(this->Nodos[N].getAltura() + 1);
            }else if((this->Nodos[CN].getValor() <this->Nodos[N].getValor() ) && (this->Nodos[N].getI() == false)){
            //Si el nodo siguiente es menor al nodo en el que estoy y ademas el nodo en el que estoy no tiene hijo izquierdo, se asigna este como el hijo izquierdo
                this->Nodos[N].setHijosI(CN);
                this->Nodos[CN].setAltura(this->Nodos[N].getAltura() + 1);
            }else if ((this->Nodos[CN].getValor() >= this->Nodos[N].getValor()) && (this->Nodos[N].getD() == true)) {
                AsignarHijos(this->Nodos[N].getHijoD(), CN);
            }else if ((this->Nodos[CN].getValor() < this->Nodos[N].getValor() ) && (this->Nodos[N].getI() == true)){
                AsignarHijos(this->Nodos[N].getHijoI(), CN);
            }
        }else{
        	this->Nodos[CN].setAltura(1);
		}


        /* Primer intento de asignacion
         * for (int i = 0; i < CN; ++i){
            if(this->Nodos[i].getCH() < 2){
                if((this->Nodos[i].getValor()>= this->Nodos[N+1].getValor()) && (this->Nodos[N].getD() == false)){
                //Si el nodo siguiente es mayor al nodo en el que estoy y ademas el nodo en el que estoy no tiene hijo derecho, se asigna este como el hijo derecho
                    this->Nodos[i].setHijosD(N+1);

                }else if((this->Nodos[i].getValor()< this->Nodos[N+1].getValor()) && (this->Nodos[N].getI() == false)){
                //Si el nodo siguiente es menor al nodo en el que estoy y ademas el nodo en el que estoy no tiene hijo izquierdo, se asigna este como el hijo izquierdo
                    this->Nodos[i].setHijosI(N+1);

                }else if ((this->Nodos[N].getValor()>= this->Nodos[N+1].getValor()) && (this->Nodos[N].getD() == true)) {

                }else if ((this->Nodos[N].getValor()< this->Nodos[N+1].getValor()) && (this->Nodos[N].getI() == true)){
                    AsignarHijos(N+1, CN-i);
                }
            }

        }*/
    }
    void Evaluar(int valorNodo){
        int eliminar = -1;

        for(int i = 0;i<CC; i++){
            if(this->Nodos[i].getValor() == valorNodo){
                eliminar = i;
                break;
            }
        }

        //cout<<eliminar;

        if(eliminar != -1){
        if(this->Nodos[eliminar].getD() == true){
            //enviamos a evaluar el hijo derecho del nodo que queremos eliminar
            HijosIzquierdos(this->Nodos[eliminar].getHijoD(), eliminar);
        }else if(this->Nodos[eliminar].getI() == true){
            //enviamos a evaluar el hijo izquierdo del nodo que queremos eliminar
            HijosDerechos(this->Nodos[eliminar].getHijoI(), eliminar);
        }else if(this->Nodos[eliminar].getD() == false && this->Nodos[eliminar].getI() == false){
            //Si el nodo a eliminar no tiene hijos solo se remueve del arreglo
            //Evaluamos de nuevo para encontrar su padre y eliminarlo de ser su hijo, sea izquierdo o derecho
            //se elimina la hoja
            for(int i = 0;i<CC; i++){
                if(this->Nodos[i].getHijoD() == eliminar){
                   this->Nodos[i].setHijosD(-1);
                }else if(this->Nodos[i].getHijoI() == eliminar){
                this->Nodos[i].setHijosI(-1);
                }
            }
            remNodo(eliminar);
        }
        }else {
        cout<<"\n\t\t\t El Nodo no existe"<<endl;
        }
    }

    void buscarNodo(int valor){
        int encontrado = -2;
        bool cent = false;
        for(int i = 0;i<CC; i++){
            if(this->Nodos[i].getValor() == valor){
            //encontrado tiene la posicion en el arreglo del nodo buscado
            encontrado = i;
                break;
            }
        }


        if(encontrado == 0){
            cout<<"Encontrado el nodo: "<<this->Nodos[encontrado].getValor()<<endl;
            cout<<"Es la Raiz: "<<endl;
            cout<<"Su Altura es: "<<this->Nodos[encontrado].getAltura()<<endl;

            if(this->Nodos[encontrado].getHijoI() != -1){
             cout<<"Su Hijo izquierdo es: "<<this->Nodos[this->Nodos[encontrado].getHijoI()].getValor()<<endl;
            }else{
            cout<<"Su Hijo izquierdo es: "<<-1<<endl;
            }
            if(this->Nodos[encontrado].getHijoD() != -1){
            cout<<"Su Hijo derecho es: "<<this->Nodos[this->Nodos[encontrado].getHijoD()].getValor()<<endl;
            }else {
            cout<<"Su Hijo derecho es: "<<-1<<endl;
            }
            cent = true;
        }
        for(int i = 0;i<CC; i++){
            if(this->Nodos[i].getHijoD() == encontrado){
               cout<<"Encontrado el nodo: "<<this->Nodos[encontrado].getValor()<<endl;
               cout<<"Su padre es: "<<this->Nodos[i].getValor()<<endl;
               cout<<"Es Hijo Derecho"<<endl;
               cout<<"Su Altura es: "<<this->Nodos[encontrado].getAltura()<<endl;
               if(this->Nodos[encontrado].getHijoI() != -1){
                cout<<"Su Hijo izquierdo es: "<<this->Nodos[this->Nodos[encontrado].getHijoI()].getValor()<<endl;
               }else{
               cout<<"Su Hijo izquierdo es: "<<-1<<endl;
               }
               if(this->Nodos[encontrado].getHijoD() != -1){
               cout<<"Su Hijo derecho es: "<<this->Nodos[this->Nodos[encontrado].getHijoD()].getValor()<<endl;
               }else {
               cout<<"Su Hijo derecho es: "<<-1<<endl;
               }
               cent = true;

            }else if(this->Nodos[i].getHijoI() == encontrado){
                cout<<"Encontrado el nodo: "<<this->Nodos[encontrado].getValor()<<endl;
                cout<<"Su padre es: "<<this->Nodos[i].getValor()<<endl;
                cout<<"Es Hijo Izquierdo"<<endl;
                cout<<"Su Altura es: "<<this->Nodos[encontrado].getAltura()<<endl;
                if(this->Nodos[encontrado].getHijoI() != -1){
                 cout<<"Su Hijo izquierdo es: "<<this->Nodos[this->Nodos[encontrado].getHijoI()].getValor()<<endl;
                }else{
                cout<<"Su Hijo izquierdo es: "<<-1<<endl;
                }
                if(this->Nodos[encontrado].getHijoD() != -1){
                cout<<"Su Hijo derecho es: "<<this->Nodos[this->Nodos[encontrado].getHijoD()].getValor()<<endl;
                }else {
                cout<<"Su Hijo derecho es: "<<-1<<endl;
                }
                cent = true;
            }
        }

        if (cent == false){
                cout<<"el Nodo no se encontro..."<<endl;
                system("pause");
        }
    }

    void HijosIzquierdos(int NodoEvaluar, int eliminar){
        //Aqui se busca el hijo mas a la izquierda del sub-arbol derecho
        if(this->Nodos[NodoEvaluar].getI() == true){
           HijosIzquierdos(this->Nodos[NodoEvaluar].getHijoI(), eliminar);
        }else{
            //no tiene hijos izquierdos entonces reasigna pero si hijos derechos
           Reasignar(NodoEvaluar, eliminar);

        }

    }

    void HijosDerechos(int NodoEvaluar, int eliminar){
        //Aqui se busca el hijo mas a la derecha del sub-arbol Izquierdo
        if(this->Nodos[NodoEvaluar].getD() == true){
           HijosDerechos(this->Nodos[NodoEvaluar].getHijoD(), eliminar);
        }else{
            //no tiene hijos derechos entonces reasigna pero si hijos izquierdos
            Reasignar(NodoEvaluar, eliminar);

        }
    }



    void Reasignar(int sustituto, int eliminar){
        //Variable para guardar los valores de cada nodo en el orden que deberian estar
        int valor[25];



        //sustituimos la posicion del nodo a eliminar con el nodo sustituto
        setNodo(eliminar,this->Nodos[sustituto]);
        //removemos el nodo que se va a mover
        remNodo(sustituto);

        for(int i= 0; i<CC ; i++){
               valor[i] = this->Nodos[i].getValor();
        }
        //cout<<CC<<endl;
        int temporal = CC;
        system("pause");
        CC = 0;
        Nodos =new Nodo[25];
        //cout<<CC<<endl;
        //volvemos a añadir los nodos en el orden de ingreso para que se respete el orden
        for(int i= 0; i<temporal ; i++){
               addNodo(Nodo(valor[i]));
        }
    }

    struct nodo{
        int dato;
        nodo *derecho;
        nodo *izquierdo;
    };

    //funcion para crear
    nodo *crearNodo(int n){
        nodo *nuevo_nodo = new nodo();

        nuevo_nodo->dato= n;
        nuevo_nodo->derecho = NULL;
        nuevo_nodo->izquierdo = NULL;

        return nuevo_nodo;
    }

    //funcion para insertar
    void insertarNodo(nodo *&arbol, int n){
        if(arbol == NULL){
            nodo *nuevo_nodo = crearNodo(n);
            arbol = nuevo_nodo;
        }else {
        int valorRaiz = arbol->dato;//obtener el valor de la raiz
        if(n<valorRaiz){
            insertarNodo(arbol->izquierdo, n);
        }else {
            insertarNodo(arbol->derecho, n);
        }
        }
    }

    void mostrarArbol(nodo *arbol, int cont){
        if(arbol == NULL){
            return;
        }else{
            mostrarArbol(arbol->derecho, cont +1);
            for (int i= 0;i <cont; i++){
                cout<<"   |";
            }
            cout<<arbol->dato<<endl;
            mostrarArbol(arbol->izquierdo, cont +1);
        }
    }

    void imprimir(){
        int valor[25];
        nodo *arbol = NULL;
        for(int i= 0; i<CC ; i++){
               valor[i] = this->Nodos[i].getValor();
        }

        for(int i= 0; i<CC ; i++){
               insertarNodo(arbol, valor[i]);
        }

        mostrarArbol(arbol, 0);
    }


};


#endif // METODOS_H
