#ifndef NODOS_H
#define NODOS_H
#include <string.h>
#include <iomanip>
#include <fstream>
#include <iostream>

using namespace std;

class Nodo{
 private:
    int Hi, Hd, altura;
    int Valor;
    bool D;
    bool I;
 public:
    Nodo(){
        Valor = 0;
        this->Hi = -1;
        this->Hd = -1;
        this->D = false;
        this->I = false;
        this->altura = 1;
    }
    Nodo(int valor){
        this->Hi = -1;
        this->Hd = -1;
       this->Valor = valor;
       this->D = false;
       this->I = false;
       this->altura = 1;
    }

    ~Nodo(){}
    
    void setAltura(int a){
    	this->altura = a;
	}
	
	int getAltura(){
		return this->altura;
	}

    void setHijosI(int H){
        if(H != -1){
        this->Hi = H;
            this->I = true;
        }else{
            this->Hi = H;
                this->I = false;
        }
    }

    void setHijosD(int H){
        if(H != -1){
        this->Hd = H;
            this->D = true;
        }else{
            this->Hd = H;
            this->D = false;
        }
    }

    void setD(bool D){
        this->D = D;
    }

    void setI(bool I){
        this->I = I;
    }

    void setValor(int V){
        this->Valor = V;
    }

    int getHijoI(){
        return this->Hi;
    }

    int getHijoD(){
        return this->Hd;
    }

    int getValor(){
        return this->Valor;
    }

    bool getD(){
        return D;
    }

    bool getI(){
        return I;
    }


};
#endif // NODOS_H
